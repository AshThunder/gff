
class RadioItem {
  dynamic value;
  String? label;

  RadioItem({
    this.value,
    this.label,
});
}