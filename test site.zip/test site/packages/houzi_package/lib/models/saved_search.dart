class SavedSearch {
  String? id;
  String? autherId;
  String? query;
  String? email;
  String? url;
  String? time;

  SavedSearch({
    this.id,
    this.autherId,
    this.query,
    this.email,
    this.url,
    this.time,
  });
}
