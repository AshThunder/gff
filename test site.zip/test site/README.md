
## Welcome to Houzi real estate app.

Houzi a real estate mobile application that connects with Houzez Wordpress theme.
A perfect compliment to your Houzez website, Houzi is a super flexible and powerful mobile app with top-notch features for real estate agents and companies.
Its build with Flutter so it can be deployed to Android and iOS.

Here are some useful links:

- View Changelog here: https://houzi-docs.booleanbites.com/changelog/
- Visit documentation here: https://houzi-docs.booleanbites.com
- Migration Guide: https://houzi-docs.booleanbites.com/tools/upgrading_future_version
